{-# LANGUAGE OverloadedStrings #-}
{-# HLINT ignore "Use lambda-case" #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# HLINT ignore "Monad law, left identity" #-}
import Data.Csv
import qualified Data.ByteString.Lazy as BL
import qualified Data.Vector as V
import System.IO (hFlush, stdout)
import System.Process ( system )
import Data.IORef
import Control.Exception (IOException, catch )
import Data.List (find)
import Control.Concurrent (threadDelay)
import Text.Regex.TDFA ((=~))
import System.Console.ANSI

data Recruiter = Recruiter
    { recruiterName :: String
    , recruiterEmail :: String 
    , recruiterPassword :: String 
    , recruiterContact :: Int 
    , companyName :: String 
    , jobTitle :: String 
    , positionOffered :: String
    } deriving (Show, Eq)

data Applicant = Applicant
    { applicantName :: String
    , applicantEmail :: String 
    , applicantPassword :: String 
    , applicantContact :: Int 
    , levelOfEducation :: String 
    , courseStudied :: String 
    , applicantExperience :: String
    } deriving (Show, Eq)

data Job = Job
    { company :: String 
    , job :: String 
    , position :: String 
    , educationalLevel :: String 
    , experience :: String 
    , relatedFields :: String 
    , shift :: String 
    , salary :: String
    } deriving (Show, Eq)

data Application = Application
    { applicantDetails :: Applicant 
    , jobDetails :: Job
    } deriving (Show, Eq)

data User = RecruiterUser Recruiter | ApplicantUser Applicant deriving (Show, Eq)

type RecruiterList = IORef [Recruiter]
type ApplicantList = IORef [Applicant]

initRecruiterList :: IO RecruiterList
initRecruiterList = newIORef []

initApplicantList :: IO ApplicantList
initApplicantList = newIORef []

type JobList = [Job]

class Users a where
    getName :: a -> String
    getEmail :: a -> String
    getPassword :: a -> String
    getContact :: a -> Int
    getLevelOfEducation :: a -> String
    getCourseStudied :: a -> String
    getUserExperience :: a -> String
    getCompanyName :: a -> String
    getJobTitle :: a -> String
    getJobPosition :: a -> String
    setName :: String -> a -> a
    setEmail :: String -> a -> a
    setPassword :: String -> a -> a
    setContact :: Int -> a -> a
    setLevelOfEducation :: String -> a -> a
    setCourseStudied :: String -> a -> a
    setExperience :: String -> a -> a
    setCompanyName :: String -> a -> a
    setJobTitle :: String -> a -> a
    setPosition :: String -> a -> a
    showProfile :: a -> String

instance Users Recruiter where
    -- getter
    getName = recruiterName
    getEmail = recruiterEmail
    getPassword = recruiterPassword
    getContact = recruiterContact
    getCompanyName = companyName
    getJobTitle = jobTitle
    getJobPosition = positionOffered
    -- setter
    setName newName recruiter = recruiter {recruiterName = newName}
    setEmail newEmail recruiter = recruiter {recruiterEmail = newEmail}
    setPassword newPassword recruiter = recruiter {recruiterPassword = newPassword}
    setContact newContact recruiter = recruiter {recruiterContact = newContact}
    setCompanyName newCompanyName recruiter = recruiter {companyName = newCompanyName}
    setJobTitle newJobTitle recruiter = recruiter {jobTitle = newJobTitle}
    setPosition newPosition recruiter = recruiter {positionOffered = newPosition}
    showProfile recruiter =
        "Name: " <> getName recruiter <>
        "\nEmail: " <> getEmail recruiter <>
        "\nPassword: " <> getPassword recruiter <>
        "\nContact: " <> show (getContact recruiter) <>
        "\nCompany Name: " <> getCompanyName recruiter <>
        "\nJob Title: " <> getJobTitle recruiter <>
        "\nPosition Offered: " <> getJobPosition recruiter 

instance Users Applicant where
    -- Getters
    getName = applicantName
    getEmail = applicantEmail
    getPassword = applicantPassword
    getContact = applicantContact
    getLevelOfEducation = levelOfEducation
    getCourseStudied = courseStudied
    getUserExperience = applicantExperience
    -- Setters
    setName newName applicant = applicant {applicantName = newName}
    setEmail newEmail applicant = applicant {applicantEmail = newEmail}
    setPassword newPassword applicant = applicant {applicantPassword = newPassword}
    setContact newContact applicant = applicant {applicantContact = newContact}
    setLevelOfEducation newLevelOfEducation applicant = applicant {levelOfEducation = newLevelOfEducation}
    setCourseStudied newCourseStudied applicant = applicant {courseStudied = newCourseStudied}
    setExperience newExperience applicant = applicant {applicantExperience = newExperience}
    showProfile applicant =
        "Name: " <> getName applicant <>
        "\nEmail: " <> getEmail applicant <>
        "\nContact: " <> show (getContact applicant) <>
        "\nLevel of Education: " <> getLevelOfEducation applicant <>
        "\nCourse studied: " <> getCourseStudied applicant <>
        "\nExperience: " <> getUserExperience applicant

class JobVacancy a where
    getCompany :: a -> String
    getJob :: a -> String
    getPosition :: a -> String
    getEducationalLevel :: a -> String
    getExperience :: a -> String
    getRelatedFields :: a -> String
    getShift :: a -> String
    getSalary :: a -> String
    showVacancy :: a -> String
    showVacancy jobVacancy =
        "Company Name: " <> getCompany jobVacancy <>
        "\nJob Scope: " <> getJob jobVacancy <>
        "\nPosition: " <> getPosition jobVacancy <>
        "\nLevel of Education: " <> getEducationalLevel jobVacancy <>
        "\nExperience: " <> getExperience jobVacancy <>
        "\nRelated Fields: " <> getRelatedFields jobVacancy <>
        "\nShift: " <> getShift jobVacancy <>
        "\nSalary: " <> getSalary jobVacancy

instance JobVacancy Job where
    getCompany = company
    getJob = job
    getPosition = position
    getEducationalLevel = educationalLevel
    getExperience = experience
    getRelatedFields = relatedFields
    getShift = shift
    getSalary = salary

instance ToRecord Recruiter where
    toRecord (Recruiter name email password contact company jobTitle position) =
        record [toField name, toField email, toField password, toField contact, toField company, toField jobTitle, toField position]

instance ToRecord Applicant where
    toRecord (Applicant name email password contact education course experience) =
        record [toField name, toField email, toField password, toField contact, toField education, toField course, toField experience]

instance ToRecord User where
    toRecord (RecruiterUser r) = toRecord r V.++ record ["Recruiter"]
    toRecord (ApplicantUser a) = toRecord a V.++ record ["Applicant"]

instance ToRecord Job where
    toRecord (Job company job position educationalLevel experience relatedFields shift salary) =
        record [toField company, toField job, toField position, toField educationalLevel, toField experience, toField relatedFields, toField shift, toField salary]

instance ToRecord Application where
    toRecord (Application applicantDetails jobDetails) =
        toRecord applicantDetails `mappend` toRecord jobDetails

instance FromRecord Recruiter where
    parseRecord v
        | V.length v == 7 = Recruiter <$> v .! 0 <*> v .! 1 <*> v .! 2 <*> (read <$> v .! 3) <*> v .! 4 <*> v .! 5 <*> v .! 6
        | otherwise = fail "Invalid Recruiter record"

instance FromRecord Applicant where
    parseRecord v
        | V.length v == 7 = Applicant <$> v .! 0 <*> v .! 1 <*> v .! 2 <*> (read <$> v .! 3) <*> v .! 4 <*> v .! 5 <*> v .! 6
        | otherwise = fail "Invalid Applicant record"

instance FromRecord User where
    parseRecord v
        | V.length v == 8 = do
            userType :: String <- v .! 7
            case userType of
                "Recruiter" -> RecruiterUser <$> parseRecord (V.init v)
                "Applicant" -> ApplicantUser <$> parseRecord (V.init v)
                _           -> fail "Unknown user type"
        | otherwise = fail "Invalid User record"

instance FromRecord Job where
    parseRecord v
        | V.length v == 8 = Job <$> v .! 0 <*> v .! 1 <*> v .! 2 <*> v .! 3 <*> v .! 4 <*> v .! 5 <*> v .! 6 <*> v .! 7
        | otherwise = fail "Invalid Job Record"

instance FromRecord Application where
    parseRecord v
        | V.length v == 15 = Application <$> parseRecord (V.take 7 v) <*> parseRecord (V.drop 7 v)
        | otherwise = fail "Invalid Application record"

clearscreen :: IO ()
clearscreen = 
    system "cls" >> return ()

readCSV :: FromRecord a => FilePath -> IO [a]
readCSV filepath = 
    putStrLn ("Reading file: " ++ filepath) >> threadDelay 500000 >> 
    BL.readFile filepath `catch` handledReadError >>= \content ->
        case decode NoHeader content of
            Left err -> 
                putStrLn ("Error decoding file: " ++ filepath ++ "-" ++ err) >>return [] -- Return empty list if decoding fails
            Right vec -> 
                return (putStrLn ("Successfully read file: " ++ filepath)) >> return $ V.toList vec --Convert vector to list
    where
        handledReadError :: IOException -> IO BL.ByteString
        handledReadError err = 
            putStrLn ("Error: Unable to read file: " ++ filepath ++ ". Reason: " ++ show err) >> return BL.empty

appendNewData :: FromRecord a => [a] -> [a] -> [a]
appendNewData previouslist newData = previouslist `mappend` newData

writetoCSV :: ToRecord a => FilePath -> [a] -> IO () 
writetoCSV filepath updatedList = 
    BL.writeFile filepath (encode updatedList)

validateEmail :: String -> Bool
validateEmail email = email =~ ("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$" :: String)

validatePhoneNumber :: String -> Bool
validatePhoneNumber phoneNum = phoneNum =~ ("^[0-9]{10,11}$" :: String)

promptEmail :: IO String
promptEmail =
    putStrLn "Email: " >> hFlush stdout >> getLine >>= \email ->
        if validateEmail email
            then return email
        else
            putStrLn "Invalid email. Please try again..." >> threadDelay 1500000 >> promptEmail

promptContactNum :: IO String
promptContactNum = putStrLn "Contact (10/11 digits): " >> hFlush stdout >> getLine >>= \contactStr ->
    if validatePhoneNumber contactStr
        then return contactStr
    else
        putStrLn "Invalid phone number. Please try again..." >> threadDelay 1500000 >> promptContactNum

isEmailTaken :: String -> [User] -> Bool
isEmailTaken email userList =
    any (\user -> case user of
        RecruiterUser recruiter -> recruiterEmail recruiter == email
        ApplicantUser applicant -> applicantEmail applicant == email) userList

loginUser :: String -> RecruiterList -> ApplicantList -> [User] -> [Job] -> [Application] -> IO ()
loginUser expectedRole recruiterList applicantList userDataList jobList applications = 
    putStr "Enter your " >>
    promptEmail >>= \email ->

    putStrLn "Enter your password: " >>
    hFlush stdout >>
    getLine >>= \password ->

    case authenticateUser expectedRole userDataList email password of
        -- General role mismatch handler
        Just (RecruiterUser recruiter) ->
                print ("Welcome Recruiter, " ++ recruiterName recruiter ++ "!") >> 
                threadDelay 1000000 >> clearscreen >> showRecruiterMenu userDataList jobList recruiter applications

        Just (ApplicantUser applicant) ->
                print ("Welcome Applicant, " ++ applicantName applicant ++ "!") >> 
                threadDelay 1000000 >> clearscreen >> showApplicantMenu userDataList jobList applications applicant

        -- Handle invalid credentials
        Nothing -> putStrLn "Invalid email and password or invalid role. Please try again." >> 
                   threadDelay 1500000 >> clearscreen >> menu recruiterList applicantList userDataList jobList applications
 
-- Function to authenticate a user
authenticateUser :: String -> [User] -> String -> String -> Maybe User
authenticateUser expectedRole users email password =
    find (\user -> case user of
        RecruiterUser recruiter -> recruiterEmail recruiter == email && recruiterPassword recruiter == password && expectedRole == "Recruiter"
        ApplicantUser applicant -> applicantEmail applicant == email && applicantPassword applicant == password && expectedRole == "Applicant") users

readContactStr :: String -> Int
readContactStr = read
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
--                                                                  Functions for Recruiters
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
recruiterloginOrSignup :: String -> RecruiterList -> ApplicantList -> [User] -> [Job] -> [Application] -> IO ()
recruiterloginOrSignup expectedRole recruiterList applicantList userDataList jobDataList applications =
    clearscreen >>
    putStrLn "Do you want to login or sign up?" >>
    putStrLn "1. Login" >>
    putStrLn "2. Sign Up" >> hFlush stdout >>
    getLine >>= \choice ->
        case choice of
            "1" -> 
                clearscreen >>
                loginUser expectedRole recruiterList applicantList userDataList jobDataList applications
            "2" -> 
                clearscreen >>
                showRecruiterSignUpMenu recruiterList userDataList jobDataList applications
            _ -> putStrLn "Invalid choice. Please try again..." >> threadDelay 1500000 >> recruiterloginOrSignup expectedRole recruiterList applicantList userDataList jobDataList applications

showRecruiterSignUpMenu :: RecruiterList -> [User] -> [Job] -> [Application] -> IO ()
showRecruiterSignUpMenu recruiterList userDataList jobDataList applications =
    putStrLn "1. Name: " >> hFlush stdout >>
    getLine >>= \name ->
    putStr "2. " >> promptEmail >>= \email -> 
        if isEmailTaken email userDataList 
            then putStrLn "The email already exist. Please try another email." >> threadDelay 1500000 >> clearscreen >> showRecruiterSignUpMenu recruiterList userDataList jobDataList applications
        else
            putStrLn "3. Password: " >> hFlush stdout >>
            getLine >>= \password ->
            putStr "4. " >> promptContactNum >>= \contactStr -> 
            putStrLn "5. Company Name: " >> hFlush stdout >>
            getLine >>= \company ->
            putStrLn "6. Job Title: " >> hFlush stdout >>
            getLine >>= \job ->
            putStrLn "7. Position: " >> hFlush stdout >>
            getLine >>= \position ->
            -- Parse contact to Int
            pure (readContactStr contactStr) >>= \contact ->
            pure (Recruiter name email password contact company job position) >>= \newRecruiter -> 
            pure (appendNewData userDataList [RecruiterUser newRecruiter]) >>= \updatedUserList -> 
            writetoCSV "app/Users.csv" updatedUserList >>
            putStrLn "Sign Up Successful!" >> threadDelay 1500000 >>
            putStrLn ("Welcome " ++ name ++ "!") >> showRecruiterMenu updatedUserList jobDataList newRecruiter applications

showRecruiterMenu :: [User] -> [Job] -> Recruiter -> [Application] -> IO ()
showRecruiterMenu userDataList jobDataList recruiter applications =
    clearscreen >>
    putStrLn "1. Propose Vacancy" >>
    putStrLn "2. Check Application" >>
    putStrLn "3. Check Profile" >>
    putStrLn "4. Edit Profile" >>
    putStrLn "5. Exit" >>
    hFlush stdout >> getLine >>= \choice ->
        case choice of
            "1" -> clearscreen >> proposeVacancy userDataList jobDataList recruiter applications
            "2" -> clearscreen >> checkApplicantJobApplication userDataList jobDataList recruiter applications
            "3" -> clearscreen >> checkRecruiterProfile userDataList jobDataList recruiter applications
            "4" -> clearscreen >> recruiterEditProfile userDataList jobDataList applications recruiter
            "5" -> writetoCSV "app/Users.csv" userDataList

proposeVacancy :: [User] -> [Job] -> Recruiter -> [Application] -> IO ()
proposeVacancy userDataList jobList recruiter applications =
    putStrLn "Job Title: "  >> hFlush stdout >> getLine >>= \job ->
    putStrLn "Position: " >> hFlush stdout >> getLine >>= \position ->
    putStrLn "Educational Level requirement: " >> hFlush stdout >> getLine >>= \educationalLevel ->
    putStrLn "Experience: " >> hFlush stdout >> getLine >>= \experience ->
    putStrLn "Related Fields: " >> hFlush stdout >> getLine >>= \relatedFields ->
    putStrLn "Full time/Part time: " >> hFlush stdout >> getLine >>= \shift ->
    putStrLn "Salary: " >> hFlush stdout >> getLine >>= \salary ->

    pure (appendNewData jobList (pure (Job (getCompanyName recruiter) job position educationalLevel experience relatedFields shift salary))) >>= \updatedList ->
    putStrLn "Proposing job vacancy..." >> threadDelay 1500000  >> putStrLn "Job vacancy successfully proposed." >> threadDelay 1500000 >>
    writetoCSV "app/Job.csv" updatedList >>
    showRecruiterMenu userDataList jobList recruiter applications

checkApplicantJobApplication :: [User] -> [Job] -> Recruiter -> [Application] -> IO ()
checkApplicantJobApplication userDataList jobDataList recruiter applications = 
    pure (getCompanyName recruiter) >>= \recruiterCompany ->  
    pure (filter (\application ->
            getCompany (jobDetails application) == recruiterCompany) applications) >>= \matchedApplications ->
    if null matchedApplications
        then putStrLn "No applicants have applied for your job vacancies" >> threadDelay 1500000 >> showRecruiterMenu userDataList jobDataList recruiter applications
    else mapM_ displayApplication matchedApplications >>
        putStrLn "Press 0 to redirect back to main menu: " >>
        hFlush stdout >> getLine >>= \choice ->
            case choice of
                "0" -> showRecruiterMenu userDataList jobDataList recruiter applications
                _ -> putStrLn "Invalid input. Please enter again." >> checkApplicantJobApplication userDataList jobDataList recruiter applications
    where
        displayApplication :: Application -> IO ()
        displayApplication application = 
            pure (getJob (jobDetails application)) >>= \jobTitle ->   -- Fetch the job title from the application
            putStrLn ("Applying for job: " `mappend` jobTitle) >>
            putStrLn (displayApplicantInfo application) >>
            putStrLn "--------------------------------------------------"

displayApplicantInfo :: Application -> String
displayApplicantInfo (Application applicantDetails _) =
    showProfile applicantDetails

checkRecruiterProfile :: [User] -> [Job] -> Recruiter -> [Application] -> IO ()
checkRecruiterProfile userDataList jobDataList recruiter applications = 
    putStrLn (showProfile recruiter) >>
    putStrLn "\nEnter 0 to redirect back to main menu: " >>
    hFlush stdout >> getLine >>= \choice -> case choice of
        "0" -> showRecruiterMenu userDataList jobDataList recruiter applications
        _ -> putStrLn "Invalid input.Please try again..." >> threadDelay 1500000 >> clearscreen >> checkRecruiterProfile userDataList jobDataList recruiter applications

recruiterEditProfile :: [User] -> [Job] -> [Application] -> Recruiter -> IO ()
recruiterEditProfile userList jobList applicationList recruiter =
    putStrLn "Edit your profile?" >>
    putStrLn "1.Name\n2.Email\n3.Password\n4.Contact\n5.Company Name\n6.Job Title\n7.Position Offered\n8.Exit" >>
    hFlush stdout >> getLine >>= \choice -> case choice of
        "1" -> putStrLn "Please enter new name: " >> hFlush stdout >> getLine >>= \newName -> updateProfile setName newName recruiter userList
        "2" -> putStr "Please enter new " >> promptEmail >>= \newEmail -> updateProfile setEmail newEmail recruiter userList
        "3" -> putStrLn "Please enter new password: " >> hFlush stdout >> getLine >>= \newPassword -> updateProfile setPassword newPassword recruiter userList
        "4" -> putStr "Please enter new " >> promptContactNum >>= \newContactStr ->
                case reads newContactStr :: [(Int, String)] of
                    [(newContact, "")] -> updateProfile setContact newContact recruiter userList
                    _ -> putStrLn "Invalid input. Please enter a valid number." >> recruiterEditProfile userList jobList applicationList recruiter
        "5" -> putStrLn "Please enter new Level of Education: " >> hFlush stdout >> getLine >>= \newCompanyName -> updateProfile setCompanyName newCompanyName recruiter userList
        "6" -> putStrLn "Please enter new course studied: " >> hFlush stdout >> getLine >>= \newJobTitle -> updateProfile setJobTitle newJobTitle recruiter userList
        "7" -> putStrLn "Please enter new experience: " >> hFlush stdout >> getLine >>= \newPosition -> updateProfile setPosition newPosition recruiter userList
        "8" -> showRecruiterMenu userList jobList recruiter applicationList
        _ -> putStrLn "Invalid choice. Please try again." >> threadDelay 1500000 >> clearscreen >> recruiterEditProfile userList jobList applicationList recruiter
    where
        updateProfile :: (a -> Recruiter -> Recruiter) -> a -> Recruiter ->  [User] -> IO ()
        updateProfile updateFunc newValue recruiter userList = 
            pure (updateFunc newValue recruiter) >>= \updatedRecruiter -> 
            pure (map (\user -> 
                case user of 
                    RecruiterUser a | recruiterEmail a == recruiterEmail recruiter && recruiterContact a == recruiterContact recruiter -> RecruiterUser updatedRecruiter
                    _ -> user) userList) >>= \updatedUserList ->
            writetoCSV "app/Users.csv" updatedUserList >>
            putStrLn "Changing profile..." >> threadDelay 1500000 >> putStrLn "Profile updated successfully!" >> threadDelay 1500000 >> clearscreen >> recruiterEditProfile updatedUserList jobList applicationList updatedRecruiter

-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
--                                                                  Functions for Applicants
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------

applicantloginOrSignup :: String -> RecruiterList -> ApplicantList -> [User] -> [Job] -> [Application] -> IO ()
applicantloginOrSignup expectedRole recruiterList applicantList userDataList jobList applicationList =
    clearscreen >>
    putStrLn "Do you want to login or sign up?" >>
    putStrLn "1. Login" >>
    putStrLn "2. Sign Up" >> hFlush stdout >>
    getLine >>= \choice ->
        case choice of
            "1" -> clearscreen >> loginUser expectedRole recruiterList applicantList userDataList jobList applicationList
            "2" -> clearscreen >> showApplicantSignUpMenu applicantList userDataList jobList applicationList 
            _ -> putStrLn "Invalid choice. Please try again..." >> threadDelay 1500000 >> applicantloginOrSignup expectedRole recruiterList applicantList userDataList jobList applicationList

showApplicantSignUpMenu :: ApplicantList -> [User] -> [Job] -> [Application] -> IO ()
showApplicantSignUpMenu applicantList userlist jobList applicationList =
    putStrLn "1. Name: " >> hFlush stdout >>
    getLine >>= \name ->
    putStr "2. " >> promptEmail >>= \email -> 
        if isEmailTaken email userlist
            then putStrLn "The email already exist. Please try another email." >> threadDelay 1500000 >> clearscreen >> showApplicantSignUpMenu applicantList userlist jobList applicationList
        else
            putStrLn "3. Password: " >> hFlush stdout >>
            getLine >>= \password ->
            putStr "4. " >> promptContactNum >>= \contactStr ->
            putStrLn "5. Level of Education: " >> hFlush stdout >>
            getLine >>= \education ->
            putStrLn "6. Course Studied: " >> hFlush stdout >>
            getLine >>= \course ->
            putStrLn "7. Experience: " >> hFlush stdout >>
            getLine >>= \experience ->
    -- Parse contact to Int
            pure (readContactStr contactStr) >>= \contact ->
            pure (Applicant name email password contact education course experience) >>= \newApplicant -> 
            pure (appendNewData userlist [ApplicantUser newApplicant]) >>= \updatedUserList -> 
            writetoCSV "app/Users.csv" updatedUserList >>
            putStrLn "Sign Up Successful!" >> threadDelay 1500000 >>
            putStrLn ("Welcome " ++ name ++ "!") >> showApplicantMenu updatedUserList jobList applicationList newApplicant

showApplicantMenu :: [User] -> [Job] -> [Application] -> Applicant -> IO ()
showApplicantMenu updatedList jobList applicationList applicant =
    clearscreen >>
    putStrLn "1. Search for Job" >>
    putStrLn "2. Check Application" >>
    putStrLn "3. Remove Application" >>
    putStrLn "4. Check Profile" >>
    putStrLn "5. Edit Profile" >>
    putStrLn "6. Exit" >>
    hFlush stdout >> getLine >>= \choice ->
        case choice of
            "1" -> clearscreen >> searchForJob updatedList jobList applicationList applicant
            "2" -> clearscreen >> applicantJobApplication updatedList jobList applicationList
            "3" -> clearscreen >> applicantRemoveJobApplication updatedList jobList applicationList
            "4" -> clearscreen >> checkApplicantProfile updatedList jobList applicationList applicant
            "5" -> clearscreen >> applicantEditProfile updatedList jobList applicationList applicant
            "6" -> writetoCSV "app/Users.csv" updatedList

searchForJob :: [User] -> [Job] -> [Application] -> Applicant -> IO ()
searchForJob updatedList jobList applicationList applicant = 
    putStrLn "-------------------------------------------------" >>
    putStrLn "Job Applications: " >>
    if null jobList
        then putStrLn "No Job Vacancies Available..."
        else 
            putStrLn "-------------------------------------------------" >>
            mapM_ printJobWithNumber (zip [1..] jobList) >>
            putStrLn "\nEnter the job number to apply for the job or 0 to exit:" >>
            hFlush stdout >>
            userChoice jobList
  where
    printJobWithNumber (n, job) = 
        putStrLn ("Job #" `mappend` show n) >> 
        putStrLn (showVacancy job) >> 
        putStrLn "-------------------------------------------------"

    userChoice jobs =
        getLine >>= \choice ->
            case reads choice :: [(Int, String)] of
                [(0, "")] -> showApplicantMenu updatedList jobList applicationList applicant
                [(n, "")] | n > 0 && n <= length jobs ->
                    pure (jobs !! (n - 1)) >>= \jobSelection ->
                        case findLoggedInApplicant updatedList of
                            Just applicant -> 
                                pure (Application applicant jobSelection) >>= \newApplication ->
                                pure (appendNewData applicationList [newApplication]) >>= \updatedJobList ->
                                writetoCSV "app/Applications.csv" updatedJobList >>
                                putStrLn ("You have applied for:\n" `mappend` showVacancy jobSelection) >>
                                putStrLn "Thank you for applying." >> threadDelay 1500000 >> clearscreen >>
                                showApplicantMenu updatedList jobList updatedJobList applicant
                            Nothing ->
                                putStrLn "Error: Unable to retrieve applicant details."
                _ -> putStrLn "Invalid choice... Please enter a valid number.\nEnter the job number to apply for the job or 0 to exit:" >>
                     userChoice jobs

applicantJobApplication :: [User] -> [Job] -> [Application] -> IO ()
applicantJobApplication userDataList jobList applications = 
    case findLoggedInApplicant userDataList of
        Just applicant -> 
            pure (filter (\application -> 
                    applicantEmail (applicantDetails application) == applicantEmail applicant) applications) >>= \matchedApplications -> 
            if null matchedApplications
                then putStrLn "You have not applied for any jobs." >> threadDelay 1500000 >>  showApplicantMenu userDataList jobList applications applicant
                else 
                    putStrLn "Your applications: " *>
                    putStrLn "-------------------------------------------------" *>
                    mapM_ printApplicationsWithNumber (zip [1..] matchedApplications) *>
                    putStrLn "Enter 0 to redirect back to main menu: " *>
                    hFlush stdout >> getLine >>= \choice ->
                        case choice of
                            "0" -> showApplicantMenu userDataList jobList applications applicant
                            _ -> putStrLn "Invalid input. Please enter again." >> threadDelay 1500000 >> applicantJobApplication userDataList jobList applications
            where
                printApplicationsWithNumber (n, application) = 
                    putStrLn ("Application #" `mappend` show n) *>
                    putStrLn (showVacancy (jobDetails application)) *>
                    putStrLn "-------------------------------------------------"

        Nothing -> putStrLn "No applicant is logged in."

applicantRemoveJobApplication :: [User] -> [Job] -> [Application] -> IO ()
applicantRemoveJobApplication updatedList jobList applicationList = 
    case findLoggedInApplicant updatedList of
        Just applicant -> 
            pure (filter (\application -> 
                    applicantEmail (applicantDetails application) == applicantEmail applicant) applicationList) >>= \matchedApplications -> 
            if null matchedApplications
                then putStrLn "You have not applied for any jobs." >> threadDelay 1500000 >> showApplicantMenu updatedList jobList applicationList applicant
                else 
                    putStrLn "Your applications: " *>
                    putStrLn "-------------------------------------------------" *>
                    mapM_ printApplicationsWithNumber (zip [1..] matchedApplications) *>
                    putStrLn "Enter the application number to remove the application or 0 to exit" *>
                    hFlush stdout *>
                    userChoice matchedApplications applicationList
            where
                printApplicationsWithNumber (n, application) = 
                    putStrLn ("Application #" `mappend` show n) *>
                    putStrLn (showVacancy (jobDetails application)) *>
                    putStrLn "-------------------------------------------------"

                userChoice applications currentApplications =
                    getLine >>= \choice ->
                        case reads choice :: [(Int, String)] of
                            [(0, "")] -> showApplicantMenu updatedList jobList applicationList applicant
                            [(n, "")] | n > 0 && n <= length applications -> 
                                pure (applications !! (n - 1)) >>= \applicationToRemove -> 
                                pure (filter (/= applicationToRemove) currentApplications) >>= \updatedApplications -> 
                                writetoCSV "app/Applications.csv" updatedApplications *>
                                putStrLn ("Application removed: " `mappend` showVacancy (jobDetails applicationToRemove)) *>
                                threadDelay 1500000 *>
                                showApplicantMenu updatedList jobList updatedApplications applicant
                            _ -> putStrLn "Invalid choice... Please enter a valid number" >> threadDelay 1500000 >> userChoice applications currentApplications

        Nothing -> putStrLn "No applicant is logged in."

checkApplicantProfile :: [User] -> [Job] -> [Application] -> Applicant -> IO ()
checkApplicantProfile updatedList jobList applicationList applicant = 
    putStrLn (showProfile applicant) >>
    putStrLn ("Password: " `mappend` getPassword applicant) >>
    putStrLn "\nEnter 0 to redirect back to main menu: " >>
    hFlush stdout >> getLine >>= \choice -> case choice of
        "0" -> showApplicantMenu updatedList jobList applicationList applicant
        _ -> putStrLn "Invalid input.Please try again..." >> threadDelay 1500000 >> clearscreen >> checkApplicantProfile updatedList jobList applicationList applicant

applicantEditProfile :: [User] -> [Job] -> [Application] -> Applicant -> IO ()
applicantEditProfile userList jobList applicationList applicant =
    putStrLn "Edit your profile?" >>
    putStrLn "1.Name\n2.Email\n3.Password\n4.Contact\n5.Level of Education\n6.Course Studied\n7.Experience\n8.Exit" >>
    hFlush stdout >> getLine >>= \choice -> case choice of
        "1" -> putStrLn "Please enter new name: " >> hFlush stdout >> getLine >>= \newName -> updateProfile setName newName applicant userList
        "2" -> putStr "Please enter new " >> promptEmail >>= \newEmail -> updateProfile setEmail newEmail applicant userList
        "3" -> putStrLn "Please enter new password: " >> hFlush stdout >> getLine >>= \newPassword -> updateProfile setPassword newPassword applicant userList
        "4" -> putStr "Please enter new " >> promptContactNum >>= \newContactStr ->
                case reads newContactStr :: [(Int, String)] of
                    [(newContact, "")] -> updateProfile setContact newContact applicant userList
                    _ -> putStrLn "Invalid input. Please enter a valid number." >> applicantEditProfile userList jobList applicationList applicant
        "5" -> putStrLn "Please enter new Level of Education: " >> hFlush stdout >> getLine >>= \newLevelOfEducation -> updateProfile setLevelOfEducation newLevelOfEducation applicant userList
        "6" -> putStrLn "Please enter new course studied: " >> hFlush stdout >> getLine >>= \newCourseStudied -> updateProfile setCourseStudied newCourseStudied applicant userList
        "7" -> putStrLn "Please enter new experience: " >> hFlush stdout >> getLine >>= \newExperience -> updateProfile setExperience newExperience applicant userList
        "8" -> showApplicantMenu userList jobList applicationList applicant
        _ -> putStrLn "Invalid choice. Please try again." >> threadDelay 1500000 >> clearscreen >> applicantEditProfile userList jobList applicationList applicant
    where
        updateProfile :: (a -> Applicant -> Applicant) -> a -> Applicant ->  [User] -> IO ()
        updateProfile updateFunc newValue applicant userList = 
            pure (updateFunc newValue applicant) >>= \updatedApplicant ->
            pure (map (\user -> case user of 
                    ApplicantUser a | applicantEmail a == applicantEmail applicant && applicantContact a == applicantContact applicant -> ApplicantUser updatedApplicant 
                    _ -> user) userList) >>= \updatedUserList -> 
            writetoCSV "app/Users.csv" updatedUserList *>
            putStrLn "Changing profile..." >> threadDelay 1500000 >> putStrLn "Profile updated successfully!" >> threadDelay 1500000 >> clearscreen >> applicantEditProfile updatedUserList jobList applicationList updatedApplicant

findLoggedInApplicant :: [User] -> Maybe Applicant
findLoggedInApplicant users = case find isApplicant users of
    Just (ApplicantUser applicant) -> Just applicant
    _ -> Nothing

isApplicant :: User -> Bool
isApplicant (ApplicantUser _) = True
isApplicant _ = False

formatCheckApplication :: Application -> String
formatCheckApplication applications = showVacancy (jobDetails applications) 

-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
--                                                                  Main Menu
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Function to print the ASCII art
printAsciiArt :: IO ()
printAsciiArt = 
    clearScreen >>
    setSGR [SetColor Foreground Vivid Green] >>
    putStrLn (unlines [
        "     ▄▄▄▄▄▄▄     ▄▄▄▄▄▄▄     ▄▄▄▄▄▄▄     ▄▄▄▄▄▄▄     ▄▄▄▄▄▄▄     ▄▄▄▄▄▄▄   ",
        "    █  ▄ ▄  █   █  ▄ ▄  █   █  ▄ ▄  █   █  ▄ ▄  █   █  ▄ ▄  █   █  ▄ ▄  █  ",
        "   ██   ▄   ██ ██   ▄   ██ ██   ▄   ██ ██   ▄   ██ ██   ▄   ██ ██   ▄   ██ ",
        "   ██  █▄█  ██ ██  █▄█  ██ ██  █ █  ██ ██  █▄█  ██ ██  █ █  ██ ██  █ █  ██ ",
        "   ██       ██ ██       ██ ██  █▄█  ██ ██       ██ ██  █▄█  ██ ██  █▄█  ██ ",
        "    █   ▄   █   █   ▄   █   █       █   █   ▄   █   █       █   █       █  ",
        "    █▄▄█ █▄▄█   █▄▄█ █▄▄█   █▄▄█ █▄▄█   █▄▄█ █▄▄█   █▄▄█ █▄▄█   █▄▄█ █▄▄█  ",
        "                                                                           ",
        "    █████████████████████████████████████████████████████████████████████  ",
        "    █                                                                   █  ",
        "    █           ╔═╗╦═╗╦╔═╗   ╔═╗╔╗╔╔═╗╦╦  ╦   ╔═╗╔╗╔╔═╗╔═╗╦╦═╗          █  ",
        "    █           ╠═╝╠╦╝║╠═╝───║ ║║║║║ ╦║║  ║───║╣ ║║║║╣ ╠═╣║╠╦╝          █  ",
        "    █           ╩  ╩╚═╩╩     ╚═╝╝╚╝╚═╝╩╩═╝╩═╝ ╚═╝╝╚╝╚═╝╩ ╩╩╩╚═          █  ",
        "    █                                                                   █  ",
        "    █████████████████████████████████████████████████████████████████████  ",        
        "            Simplifying Your Career Path - Job Application System          ",
        "                    ╔══════════════════════════════════╗                   ",
        "                    ║      APPLY | GROW | SUCCEED      ║                   ",
        "                    ╚══════════════════════════════════╝                   "
    ]) >>
    setSGR [Reset]

menu :: RecruiterList -> ApplicantList -> [User] -> [Job] -> [Application] -> IO ()
menu recruiterList applicantList userDataList jobDataList applicationsDataList =
    printAsciiArt >>
    putStrLn "Are you a recruiter or applicant?" *>
    putStrLn "1. Recruiter" *>
    putStrLn "2. Applicant" *>
    putStrLn "3. Exit" *>
    getLine >>= \choice ->
        case choice of
            "1" -> recruiterloginOrSignup "Recruiter" recruiterList applicantList userDataList jobDataList applicationsDataList
            "2" -> applicantloginOrSignup "Applicant" recruiterList applicantList userDataList jobDataList applicationsDataList
            "3" -> putStrLn "Exiting..." >> threadDelay 1000000 >> clearscreen
            _   -> putStrLn "Invalid choice.Please try again..." >> threadDelay 1500000 >> main

main :: IO ()
main = 
    clearscreen >>
    initRecruiterList >>= \recruiterList ->
    initApplicantList >>= \applicantList -> 
    pure "app/Users.csv" >>= \userFilePath ->
    pure "app/Job.csv" >>= \jobFilePath ->
    pure "app/Applications.csv" >>= \applicationsFilePath ->

    readCSV userFilePath >>= \userDataList -> 
    readCSV jobFilePath >>= \jobDataList ->
    readCSV applicationsFilePath >>= \applicationsDataList ->
        menu recruiterList applicantList userDataList jobDataList applicationsDataList 